# Layout-specificatie v4401

## Algemene werkwijze

De layout werkt bottom-up:

```text
1. lees structure-config
2. bouw subtree-objecten
3. bereken per leaf een minimale box
4. combineer children recursief
5. zoek per child-subtree een vrije plaats
6. reserveer bezette cellen en HOR/VER-corridors
7. render nodes, boxen en edges
```

## Geen containment-layout

De layout mag niet simpelweg alle children naast elkaar in een parent-box zetten. Child-subtrees worden als zelfstandige boxen geplaatst op vrije posities.

## Layout order

```text
left-first  = eerste kandidaat zoekt links, daarna alternerend verder
right-first = eerste kandidaat zoekt rechts, daarna alternerend verder
```

Geldt voor syntax en functioneel.

## Takvolgorde

```text
normaal              = children in structure-config-volgorde
flip alle vertakkingen = children in omgekeerde volgorde bij iedere vertakking
```

Dit verandert alleen de plaatsingsvolgorde van subtree-boxes. Subject blijft subject, object blijft object, predicate blijft predicate.

## Syntax

Standaard:

```text
S → NP VP
VP → NP V
V → predicate
```

Perfectum kan in structure-config worden gezet als:

```text
VP → NP VP
VP → pv vdw
```

## Functioneel

Standaard:

```text
CLAUSE
├─ PRED
│  └─ predicate
└─ ARG-STRUCT
   ├─ ARG1
   │  └─ NP
   │     └─ subject
   └─ ARG2
      └─ NP
         └─ object
```

Hierdoor zijn `PRED` en `ARG-STRUCT` zelfstandige subtree-boxes. De structuur kan vrijer worden geplaatst dan bij `CLAUSE → AGENS PRED PATIENS`.
