# Design decisions v4401

1. De boom wordt niet handmatig top-down getekend.
2. De boom wordt bottom-up recursief opgebouwd.
3. Per subtree worden eerst boxmaten en bezette cellen bepaald.
4. Daarna zoekt de layout vrije HOR/VER-plaatsen.
5. Pas na plaatsing wordt gerenderd.
6. Syntax en functioneel zijn aparte OPN-bronnen.
7. Functioneel gebruikt `CLAUSE → PRED ARG-STRUCT` zodat predicaat en argumentstructuur als eigen subtree-boxen vrij kunnen worden geplaatst.
8. Lexicale woorden staan niet in `structure-config.html`.
9. Woorden staan in `lexicon-config.html`.
10. Voorbeeldzinnen koppelen lexemen aan abstracte sources zoals `subject`, `object`, `predicate`, `pv`, `vdw`.
11. Lidwoorden/determinatoren zijn voorlopig uit het systeem verwijderd.
12. `Wissel S/O` wisselt lexicale vulling, niet de structurele rollen.
13. `Layout order` bepaalt de zoekrichting van vrije plaatsing: `left-first` of `right-first`.
14. `Takvolgorde` kan alle vertakkingen normaal of geflipt plaatsen.
15. Flip is layout, geen grammaticale transformatie.
16. Topicalisatie wordt voorbereid via een slot tussen beginknoop en bovenste boomknoop.
17. `slot 0` is Comp/(om)dat op LEX, boven de S/CLAUSE-box.
18. `slot 1` is vooropplaatsing/topicalisatie tussen startknoop en bovenste boomlaag.
