# Screenshot notes v4401

Bewaar screenshots in een map naast `docs/`:

```text
screenshots/
```

Aanbevolen naamgeving:

```text
v4401-syntax-left-normal.png
v4401-syntax-right-flip.png
v4401-functional-left-normal.png
v4401-functional-right-flip.png
v4401-lex-perfectum.png
```

Leg per screenshot vast:

```text
versie
browser
gekozen voorbeeldzin
Centraal OPN: syntax/functioneel
Layout order
Takvolgorde
opmerking/fout/verwacht gedrag
```

Gebruik screenshots later voor `USER_GUIDE_DRAFT.md` en uiteindelijke documentatie.
