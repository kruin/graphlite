# Current state v4401

## Actief

- Viewer start lokaal op `http://localhost:8088`.
- No-cache server is actief via `server_nocache.py`.
- Service worker wordt niet meer actief gebruikt; oude service workers worden opgeruimd.
- Syntaxboom werkt bottom-up recursief.
- Functionele structuur werkt bottom-up recursief.
- Functioneel gebruikt `PRED` apart van `ARG-STRUCT`.
- LEX-projecties zijn horizontaal.
- `slot 0` is Comp/(om)dat.
- `slot 1` is vooropplaatsing/topicalisatie.
- Lidwoorden zijn verwijderd.
- Voorbeeldzinnen worden gevoed door `examples-input.html`.
- Voorbeeldeditor gebruikt `lexicon-config.html` en `structure-config.html`.
- `Layout order` werkt voor syntax en functioneel.
- `Takvolgorde` kan alle vertakkingen flippen.

## Huidige voorbeeldzinnen

```text
HOND BIJT MAN
OMDAT HOND MAN BIJT
VROUW BREIT TRUI
OMDAT VROUW TRUI BREIT
HOND HEEFT MAN GEBETEN
```

## Versie-opmerking

v4401 voegt projectdocumentatie toe. Functionele of visuele layoutlogica is inhoudelijk gelijk aan v4400.
