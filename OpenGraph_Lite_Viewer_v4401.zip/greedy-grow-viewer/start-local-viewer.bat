@echo off
setlocal
cd /d "%~dp0"
echo.
echo OpenGraph Lite Viewer v4401
echo.
echo Start lokale server op http://localhost:8088
echo Gebruik 8088. Deze server stuurt no-cache headers mee.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py server_nocache.py
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  python server_nocache.py
  goto :eof
)
echo FOUT: Python niet gevonden. Installeer Python of publiceer deze map via GitHub Pages.
pause
